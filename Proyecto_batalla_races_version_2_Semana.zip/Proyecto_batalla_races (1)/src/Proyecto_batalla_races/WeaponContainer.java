package Proyecto_batalla_races;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;



public class WeaponContainer extends Main{
	protected ArrayList<Weapon> weapons = new ArrayList<Weapon>();
	
	public WeaponContainer() {
		
		try {
			createConnection();
			String query = "select * from weapons";
			Statement stmt = conn.createStatement();
			ResultSet rs1 = stmt.executeQuery(query);
			while(rs1.next()) {
				weapons.add(new Weapon(rs1.getInt(1), rs1.getString(2), rs1.getString(3), rs1.getInt(4), rs1.getInt(5),  rs1.getString(6)));
				}
			
		} catch (SQLException e) {
		System.out.println("Error de SQL.");
		
		}
	}
}

class Weapon{
	int id ;
	String name;
	String image;
	int strength;
	int speed;
	String race;
	
	
	public Weapon(int id, String name, String image, int strength, int speed, String race) {
		super();
		this.id = id;
		this.name = name;
		this.image = image;
		this.strength = strength;
		this.speed = speed;
		this.race = race;
	}
	
}
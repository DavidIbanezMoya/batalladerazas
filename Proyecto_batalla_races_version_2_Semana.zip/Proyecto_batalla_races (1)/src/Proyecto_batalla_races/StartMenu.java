package Proyecto_batalla_races;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

public class StartMenu extends JFrame implements ActionListener{
	protected JPanel top_buttons,center_battle,bottom_terminal,bottom_buttons,center_general;
	protected JButton choosechar, chooseweap, rank, fight, clconsole;
	protected JLabel power,agility,speed,defense, weaponimage;
	protected JProgressBar healthpoints,powerbar,agilitybar,speedbar,defensebar;
	protected Character user,bot;
	private JTextArea txtConsole;

	
	public StartMenu() {
		Container general = getContentPane();
		
		user = new Character();
		bot = new Character();
		//this.setResizable(false);
		//JPanels from the main
		top_buttons = new JPanel();
		JPanelBackground center_general = new JPanelBackground();
		
		center_general.setBackgroundI("images/dbz.jpg");
		center_battle = new JPanel();
		top_buttons.setOpaque(false);
		center_general.setOpaque(false);
		user.setOpaque(false);
		bot.setOpaque(false);
		
		bottom_terminal = new JPanel();
		bottom_buttons = new JPanel();


		setTitle("This is a provisional title");
		setBounds(250,0,1000,750);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		general.add(top_buttons, BorderLayout.NORTH);
		general.add(center_battle, BorderLayout.CENTER);
		general.add(bottom_terminal, BorderLayout.SOUTH);
		
		//top_buttons.setBackground(Color.red);
		top_buttons.setPreferredSize(new Dimension(800,50));
		bottom_terminal.setBackground(Color.red);
		bottom_terminal.setPreferredSize(new Dimension(800,150));

		//Preparing the buttons
		
		choosechar = new JButton("Choose character");
		chooseweap = new JButton("Choose weapon");
		rank = new JButton("Ranking");
		
		top_buttons.add(choosechar);
		top_buttons.add(chooseweap);
		top_buttons.add(rank);
		
		//Battle part
		
		center_battle.setLayout(new BoxLayout(center_battle, BoxLayout.Y_AXIS));
		center_general.setLayout(new BoxLayout(center_general, BoxLayout.X_AXIS));
		
		
		center_battle.add(center_general);

		center_battle.add(bottom_buttons);
		
		center_general.add(user);
		
		center_general.add(Box.createHorizontalStrut(125));
		center_general.add(bot);
		user.characterImage("images/warriors/kazuma.png");
		user.weaponImage("images/weapons/nightharv.png");

		//Bottom part of the center
		fight = new JButton("Fight");
		clconsole = new JButton("Clear console");
		bottom_buttons.add(fight);
		bottom_buttons.add(clconsole);
		//Terminal
		txtConsole = new JTextArea(7,0);
		txtConsole.setEditable(false);
        JScrollPane jsp = new JScrollPane(txtConsole);
        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        jsp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        this.add(jsp,BorderLayout.SOUTH);
        PrintStream out = new PrintStream( new ConsoleJFrame( txtConsole ));
        System.setOut( out );
        clconsole.addActionListener(this);
        fight.addActionListener(this);
        
		setVisible(true);
		
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("Clear console")) {
			txtConsole.setText("");
		}
		if (e.getActionCommand().equals("Fight")) {
			System.out.println("TATAKAEEE TATAKAE!!!");
		}
	}


}
class JPanelBackground extends JPanel {
	 
	// Atributo que guardara la imagen de Background que le pasemos.
	private Image background;
 
	// Metodo que es llamado automaticamente por la maquina virtual Java cada vez que repinta
	public void paintComponent(Graphics g) {
 
		/* Obtenemos el tamaño del panel para hacer que se ajuste a este
		cada vez que redimensionemos la ventana y se lo pasamos al drawImage */
		int width = this.getSize().width;
		int height = this.getSize().height;
 
		// Mandamos que pinte la imagen en el panel
		if (this.background != null) {
			g.drawImage(this.background, 0, 0, width, height, null);
		}
 
		super.paintComponent(g);
	}
 
	// Metodo donde le pasaremos la dirección de la imagen a cargar.
	public void setBackgroundI(String imagePath) {
		
		// Construimos la imagen y se la asignamos al atributo background.
		this.setOpaque(false);
		this.background = new ImageIcon(imagePath).getImage();
		repaint();
	}
 
}
class Character extends JPanel {
	//Left Character
	protected JPanel character1,character1hp,character1image,character1stats,character1statsinfo,character1weapon,character1bars;
	protected JLabel power,agility,speed,defense, weaponimage,characterimage;
	protected JProgressBar healthpoints,powerbar,agilitybar,speedbar,defensebar;
	private Toolkit pantalla;
	protected WarriorContainer warc;
	protected WeaponContainer wepc;
	public Character(){
		warc = new WarriorContainer();
		wepc = new WeaponContainer();
		character1 = new JPanel();
		character1hp = new JPanel();
		character1image = new JPanel();
		character1stats = new JPanel();
		character1statsinfo = new JPanel();
		character1weapon = new JPanel();
		character1bars = new JPanel();
		
		character1.setOpaque(false);
		character1hp.setOpaque(false);
		character1image.setOpaque(false);
		character1stats.setOpaque(false);
		character1statsinfo.setOpaque(false);
		character1weapon.setOpaque(false);
		
		this.setPreferredSize(new Dimension(0,500));
		
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.add(character1hp);
	
		//Poner en el segundo parametro un get de la vida de la raza
		healthpoints = new JProgressBar(0,60);
		//healthpoints.setMaximum(warc.warriors.get(1).hp);
		//EL parametro seria calcualr la vida acutal, despues de los daños recibidos
		//healthpoints.setValue(warc.warriors.get(1).hp);
		healthpoints.setStringPainted(true);
		healthpoints.setForeground(Color.green);
		healthpoints.setBackground(Color.LIGHT_GRAY);
		healthpoints.setPreferredSize(new Dimension(410,30));
		
		character1hp.setBackground(Color.black);
		character1hp.setPreferredSize(new Dimension(0,-100));
		//character1hp.setBorder(BorderFactory.createLineBorder(Color.black,12));
		character1hp.add(healthpoints);
		this.add(character1image);
		characterimage = new JLabel();
		pantalla = Toolkit.getDefaultToolkit();


		character1image.setPreferredSize(new Dimension(0,150));
		this.add(character1stats);
		character1stats.setPreferredSize(new Dimension(0,-50));
	
		//Weapon image
		weaponimage = new JLabel();
	    character1weapon.setBackground(Color.yellow);
		character1stats.add(weaponimage);
		
		//Stats
		power = new JLabel("Power");
		defense = new JLabel("Defense");
		agility = new JLabel("Agility");
		speed = new JLabel("Speed");
		
		power.setForeground(Color.white);
		defense.setForeground(Color.white);
		agility.setForeground(Color.white);
		speed.setForeground(Color.white);

		character1stats.setLayout(new GridLayout(1,3));
	
		character1statsinfo.setPreferredSize(new Dimension(3,3));
		character1statsinfo.setLayout(new GridLayout(4,1,0,15));
		character1statsinfo.add(power);
		character1statsinfo.add(defense);
		character1statsinfo.add(agility);
		character1statsinfo.add(speed);
		character1stats.add(character1statsinfo);
		
		//Bar
		character1bars.setLayout(new GridLayout(4,1));
	
		powerbar = new JProgressBar(0,11);
		//powerbar.setValue(warc.warriors.get(0).strength+wepc.weapons.get(7).strength);
		powerbar.setForeground(Color.red);
		powerbar.setBackground(Color.LIGHT_GRAY);
		powerbar.setPreferredSize(new Dimension(60,10));
		powerbar.setBorder(BorderFactory.createLineBorder(Color.black,3));
		character1bars.add(powerbar);
	
		defensebar = new JProgressBar(0,4);
		defensebar.setValue(warc.warriors.get(1).defense);
		defensebar.setForeground(Color.orange);
		defensebar.setBackground(Color.LIGHT_GRAY);
		defensebar.setPreferredSize(new Dimension(60,10));
		defensebar.setBorder(BorderFactory.createLineBorder(Color.black,3));
		character1bars.add(defensebar);
		
		agilitybar = new JProgressBar(0,7);
		agilitybar.setValue(warc.warriors.get(1).agility);
		agilitybar.setForeground(Color.cyan);
		agilitybar.setBackground(Color.LIGHT_GRAY);
		agilitybar.setPreferredSize(new Dimension(60,10));
		agilitybar.setBorder(BorderFactory.createLineBorder(Color.black,3));
		character1bars.add(agilitybar);
		
		speedbar = new JProgressBar(0,12);
		//speedbar.setValue(warc.warriors.get(2).speed+wepc.weapons.get(5).speed);
		speedbar.setForeground(Color.blue);
		speedbar.setBackground(Color.LIGHT_GRAY);
		speedbar.setPreferredSize(new Dimension(60,10));
		speedbar.setBorder(BorderFactory.createLineBorder(Color.black,3));
		character1bars.add(speedbar);
		character1stats.add(character1bars);
	}
	
	public void characterImage(String imagen) {
		pantalla = Toolkit.getDefaultToolkit();
		Image characima = pantalla.getImage(imagen);
		Image cimg = characima.getScaledInstance(500, 341,
	           Image.SCALE_SMOOTH);
	    ImageIcon imageCa = new ImageIcon(cimg);
	    characterimage.setIcon(imageCa);
		character1image.add(characterimage);
	}
	
	public void weaponImage(String arma) {
			pantalla = Toolkit.getDefaultToolkit();

			Image imagencompu = pantalla.getImage(arma);
			Image dimg = imagencompu.getScaledInstance(120, 110,
		           Image.SCALE_SMOOTH);
		    ImageIcon imageIcon = new ImageIcon(dimg);
			   weaponimage.setIcon(imageIcon);

	}
	public JPanel getCharacter1() {
		return character1;
	}
	public void setCharacter1(JPanel character1) {
		this.character1 = character1;
	}
	public JPanel getCharacter1hp() {
		return character1hp;
	}
	public void setCharacter1hp(JPanel character1hp) {
		this.character1hp = character1hp;
	}
	public JPanel getCharacter1image() {
		return character1image;
	}
	public void setCharacter1image(JPanel character1image) {
		this.character1image = character1image;
	}
	public JPanel getCharacter1stats() {
		return character1stats;
	}
	public void setCharacter1stats(JPanel character1stats) {
		this.character1stats = character1stats;
	}
	public JPanel getCharacter1statsinfo() {
		return character1statsinfo;
	}
	public void setCharacter1statsinfo(JPanel character1statsinfo) {
		this.character1statsinfo = character1statsinfo;
	}
	public JPanel getCharacter1weapon() {
		return character1weapon;
	}
	public void setCharacter1weapon(JPanel character1weapon) {
		this.character1weapon = character1weapon;
	}
	public JPanel getCharacter1bars() {
		return character1bars;
	}
	public void setCharacter1bars(JPanel character1bars) {
		this.character1bars = character1bars;
	}
	public JLabel getPower() {
		return power;
	}
	public void setPower(JLabel power) {
		this.power = power;
	}
	public JLabel getAgility() {
		return agility;
	}
	public void setAgility(JLabel agility) {
		this.agility = agility;
	}
	public JLabel getSpeed() {
		return speed;
	}
	public void setSpeed(JLabel speed) {
		this.speed = speed;
	}
	public JLabel getDefense() {
		return defense;
	}
	public void setDefense(JLabel defense) {
		this.defense = defense;
	}
	public JLabel getWeaponimage() {
		return weaponimage;
	}
	public void setWeaponimage(JLabel weaponimage) {
		this.weaponimage = weaponimage;
	}
	public JProgressBar getHealthpoints() {
		return healthpoints;
	}
	public void setHealthpoints(JProgressBar healthpoints) {
		this.healthpoints = healthpoints;
	}
	public JProgressBar getPowerbar() {
		return powerbar;
	}
	public void setPowerbar(JProgressBar powerbar) {
		this.powerbar = powerbar;
	}
	public JProgressBar getAgilitybar() {
		return agilitybar;
	}
	public void setAgilitybar(JProgressBar agilitybar) {
		this.agilitybar = agilitybar;
	}
	public JProgressBar getSpeedbar() {
		return speedbar;
	}
	public void setSpeedbar(JProgressBar speedbar) {
		this.speedbar = speedbar;
	}
	public JProgressBar getDefensebar() {
		return defensebar;
	}
	public void setDefensebar(JProgressBar defensebar) {
		this.defensebar = defensebar;
	}
}

class ConsoleJFrame extends OutputStream {
    private JTextArea textArea;

    public ConsoleJFrame( JTextArea text ) {
        textArea = text;
    }

    public void write(int b) throws IOException {
        textArea.append( String.valueOf((char)b) );
    }
  
}
package Proyecto_batalla_races;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JProgressBar;

public class Main{
	
    public static void main(String[] args) {
    	StartMenu battle =new StartMenu();
    	//battle.user.characterImage("images/warriors/ornn.png");
    	int randomWar = (int)(Math.random()*11);
    	int randomWea = (int)(Math.random()*8);
    	battle.bot.characterImage(battle.bot.warc.warriors.get(randomWar).image);
    	battle.bot.weaponImage(battle.bot.wepc.weapons.get(randomWea).image);
    	battle.bot.healthpoints.setMaximum(battle.bot.warc.warriors.get(randomWar).hp);
    	battle.bot.healthpoints.setValue(battle.bot.warc.warriors.get(randomWar).hp);
    	battle.bot.powerbar.setValue(battle.bot.warc.warriors.get(randomWar).strength+battle.bot.wepc.weapons.get(randomWea).strength);
    	battle.bot.defensebar.setValue(battle.bot.warc.warriors.get(randomWar).defense);
    	battle.bot.agilitybar.setValue(battle.bot.warc.warriors.get(randomWar).agility);
    	battle.bot.speedbar.setValue(battle.bot.warc.warriors.get(randomWar).speed+battle.bot.wepc.weapons.get(randomWea).speed);


    }
    
    static Connection conn;
    public static void createConnection() {

        String url = "jdbc:mysql://localhost/project?serverTimezone=UTC";
        String usuario = "root";
        String pass = "root1234";
        try {
//            Cargar driver
            Class.forName("com.mysql.cj.jdbc.Driver");
//            System.out.println("Se ha cargado el driver");
//            Crear coneccion
            conn = DriverManager.getConnection(url,usuario,pass);
//            System.out.println("Coneccion creada correctamente");
//            System.out.println(new String(new char[30]).replace("\0","*") + "\n");

        } catch (ClassNotFoundException e) {
            System.out.println("No se ha cargado el driver");

        } catch (SQLException e) {
            System.out.println("No se ha creado la coneccion");
        }

    }
}
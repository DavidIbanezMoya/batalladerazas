package Proyecto_batalla_races;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;



public class WarriorContainer extends Main{
	protected ArrayList<Warrior> warriors = new ArrayList<Warrior>();
	
	public WarriorContainer() {
		
		try {
			createConnection();
			String query = "select * from warriors";
			Statement stmt = conn.createStatement();
			ResultSet rs1 = stmt.executeQuery(query);
			while(rs1.next()) {
				query = "select * from race where race_id = ?";
				PreparedStatement ps = conn.prepareStatement(query);
				ps.setInt(1, rs1.getInt(4));
				ResultSet rs2 = ps.executeQuery();
				while (rs2.next()) {
					warriors.add(new Warrior(rs1.getInt(1), rs1.getString(2), rs1.getString(3), rs2.getString(2), 
								rs2.getInt(3), rs2.getInt(4), rs2.getInt(5), rs2.getInt(6), rs2.getInt(7)));
				}
			}
			
		} catch (SQLException e) {
		System.out.println("Error de SQL.");
		
		}
	}
}

class Warrior{
	int id ;
	String name;
	String image;
	String race;
	int hp;
	int strength;
	int speed;
	int agility;
	int defense;
	
	public Warrior(int id, String name, String image, String race, int hp, int strength, int speed, int agility,
			int defense) {
		super();
		this.id = id;
		this.name = name;
		this.image = image;
		this.race = race;
		this.hp = hp;
		this.strength = strength;
		this.speed = speed;
		this.agility = agility;
		this.defense = defense;
	}
}
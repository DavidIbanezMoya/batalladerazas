package Project_battle_races;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Data extends JFrame implements ActionListener{
	private JPanel griddata, flowdata;
	private JPanelBackground generaldata;
	private JTextField userfield,databaseuserfield;
	private JLabel userlabel, databaselabel, passwordlabel, register;
	private JPasswordField passwordfield;
	private JButton submit;
	private String userinput,datainput,passinput;
	protected StartMenu battle;

	public Data() {
		generaldata = new JPanelBackground();
		generaldata.setBackgroundI("images/back3.jpg");
		griddata = new JPanel();
		flowdata = new JPanel();
		griddata.setOpaque(false);
		flowdata.setOpaque(false);

		setTitle("Register / Log In");
		setBounds(500,200,500,500);
		
		//We will create the labels and textfields for the requiered inputs to get to the app.
		register = new JLabel("Register / Log In");
		register.setFont(new Font("Liberation Sans",Font.BOLD,30));
		register.setAlignmentX(CENTER_ALIGNMENT);
		
		userlabel = new JLabel("Nickname");
		userfield = new JTextField();
		databaselabel = new JLabel("Your account database user");
		databaseuserfield = new JTextField();
		passwordlabel = new JLabel("Password of the user");
		passwordfield = new JPasswordField();
		
		submit = new JButton("Submit");
		submit.setAlignmentX(CENTER_ALIGNMENT);
		this.add(generaldata);
		generaldata.setLayout(new BoxLayout(generaldata, BoxLayout.Y_AXIS));
		griddata.setLayout(new GridLayout(3,2,10,10));
		flowdata.setLayout(new FlowLayout());

		griddata.add(userlabel);
		griddata.add(userfield);
		griddata.add(databaselabel);
		griddata.add(databaseuserfield);
		griddata.add(passwordlabel);
		griddata.add(passwordfield);
		
		flowdata.add(griddata);

		generaldata.add(register);
		generaldata.add(Box.createVerticalStrut(100));

		generaldata.add(flowdata);

		generaldata.add(submit);
		generaldata.add(Box.createVerticalStrut(175));
		
		submit.addActionListener(this);
		setVisible(true);
	}
	
	

	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("Submit")) {
			userinput = userfield.getText();
			datainput = databaseuserfield.getText();
			passinput = passwordfield.getText();
			if (userinput.trim().length() == 0|| datainput.trim().length() == 0 || passinput.trim().length() == 0) {
				JOptionPane.showMessageDialog(this, "There is an empty field");
			} else {
				try {
					new InsertPlayer();
					battle = new StartMenu();
					super.dispose();
				}catch(Exception a){
					
				}
			}
		}
	}
	
	
	public JTextField getUserfield() {
		return userfield;
	}

	public JTextField getDatabaseuserfield() {
		return databaseuserfield;
	}

	public JPasswordField getPasswordfield() {
		return passwordfield;
	}

	public String getUserinput() {
		return userinput;
	}

	public String getDatainput() {
		return datainput;
	}

	public String getPassinput() {
		return passinput;
	}

}

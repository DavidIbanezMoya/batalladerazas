package Project_battle_races;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

public class Character extends JPanel {

	
	private JPanel character1,character1hp,character1image,character1stats,character1statsinfo,character1weapon,character1bars;
	private JLabel power,agility,speed,defense, weaponimage,characterimage;
	private JProgressBar healthpoints,powerbar,agilitybar,speedbar,defensebar;
	private Toolkit pantalla;
	
	public Character(){
		character1 = new JPanel();
		character1hp = new JPanel();
		character1image = new JPanel();
		character1stats = new JPanel();
		character1statsinfo = new JPanel();
		character1weapon = new JPanel();
		character1bars = new JPanel();
		
		character1.setOpaque(false);
		character1hp.setOpaque(false);
		character1image.setOpaque(false);
		character1stats.setOpaque(false);
		character1statsinfo.setOpaque(false);
		character1weapon.setOpaque(false);
		
		
		this.setPreferredSize(new Dimension(0,500));
		
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.add(character1hp);
	
		//Poner en el segundo parametro un get de la vida de la raza
		healthpoints = new JProgressBar(0,60);
		
		//EL parametro seria calcualr la vida acutal, despues de los danyos recibidos
		healthpoints.setStringPainted(true);
		healthpoints.setForeground(Color.green);
		healthpoints.setBackground(Color.LIGHT_GRAY);
		healthpoints.setPreferredSize(new Dimension(410,30));
		
		character1hp.setBackground(Color.black);
		character1hp.setPreferredSize(new Dimension(0,-100));
		//character1hp.setBorder(BorderFactory.createLineBorder(Color.black,12));
		character1hp.add(healthpoints);
		this.add(character1image);
		characterimage = new JLabel();
		pantalla = Toolkit.getDefaultToolkit();

		character1image.setPreferredSize(new Dimension(0,150));
		this.add(character1stats);
		character1stats.setPreferredSize(new Dimension(0,-50));
	
		//Weapon image
		weaponimage = new JLabel();
	    character1weapon.setBackground(Color.yellow);
		character1stats.add(weaponimage);
		
		//Stats
		power = new JLabel("Power");
		defense = new JLabel("Defense");
		agility = new JLabel("Agility");
		speed = new JLabel("Speed");
		
		power.setForeground(Color.white);
		defense.setForeground(Color.white);
		agility.setForeground(Color.white);
		speed.setForeground(Color.white);

		
		
		character1stats.setLayout(new GridLayout(1,3));
	
		character1statsinfo.setPreferredSize(new Dimension(3,3));
		character1statsinfo.setLayout(new GridLayout(4,1,0,15));
		character1statsinfo.add(power);
		character1statsinfo.add(defense);
		character1statsinfo.add(agility);
		character1statsinfo.add(speed);
		character1stats.add(character1statsinfo);
		
		//Bar
		character1bars.setLayout(new GridLayout(4,1));
	
		powerbar = new JProgressBar(0,11);
		//powerbar.setValue(warc.warriors.get(0).strength+wepc.weapons.get(7).strength);
		powerbar.setForeground(Color.red);
		powerbar.setBackground(Color.LIGHT_GRAY);
		powerbar.setPreferredSize(new Dimension(60,10));
		powerbar.setBorder(BorderFactory.createLineBorder(Color.black,3));
		character1bars.add(powerbar);
	
		defensebar = new JProgressBar(0,4);
		defensebar.setForeground(Color.orange);
		defensebar.setBackground(Color.LIGHT_GRAY);
		defensebar.setPreferredSize(new Dimension(60,10));
		defensebar.setBorder(BorderFactory.createLineBorder(Color.black,3));
		character1bars.add(defensebar);
		
		agilitybar = new JProgressBar(0,7);
		agilitybar.setForeground(Color.cyan);
		agilitybar.setBackground(Color.LIGHT_GRAY);
		agilitybar.setPreferredSize(new Dimension(60,10));
		agilitybar.setBorder(BorderFactory.createLineBorder(Color.black,3));
		character1bars.add(agilitybar);
		
		speedbar = new JProgressBar(0,12);
		//speedbar.setValue(warc.warriors.get(2).speed+wepc.weapons.get(5).speed);
		speedbar.setForeground(Color.blue);
		speedbar.setBackground(Color.LIGHT_GRAY);
		speedbar.setPreferredSize(new Dimension(60,10));
		speedbar.setBorder(BorderFactory.createLineBorder(Color.black,3));
		character1bars.add(speedbar);
		character1stats.add(character1bars);
		
		setBorder(BorderFactory.createEmptyBorder(0,50,0,50));
	}
	
	public void characterImage(String imagen) {
		character1image.add(characterimage);
		pantalla = Toolkit.getDefaultToolkit();
		Image characima = pantalla.getImage(imagen);
		Image cimg = characima.getScaledInstance(500, 340, Image.SCALE_SMOOTH);
	    ImageIcon imageCa = new ImageIcon(cimg);
	    characterimage.setIcon(imageCa);
		
	}
	
	public void weaponImage(String arma) {
		pantalla = Toolkit.getDefaultToolkit();

		Image imagencompu = pantalla.getImage(arma);
		Image dimg = imagencompu.getScaledInstance(120, 120, Image.SCALE_SMOOTH);
	    ImageIcon imageIcon = new ImageIcon(dimg);
	    weaponimage.setIcon(imageIcon);

	}
	
	public void setDates(Warrior warrior, Weapon weapon){
	    characterimage.setToolTipText("<html><p>" + warrior.getName() + "<br>Race: " + warrior.getRace() + "</p></html>" );
	    weaponimage.setToolTipText("<html><p>" + weapon.getName() + "</p></html>"+ "<br>Power: " + weapon.getStrength()
		  + "<br>Speed: " + weapon.getSpeed() + "</p></html>");
	    powerbar.setToolTipText("<html><p>Power: "+ (warrior.getStrength() + weapon.getStrength())+"/11" + "<br>Warrior: " + warrior.getStrength()
		  + "<br>Weapon: " + weapon.getStrength() + "</p></html>");
	    defensebar.setToolTipText("<html><p>Defence: "+ warrior.getDefense() +"/4" + "</p></html>");
	    agilitybar.setToolTipText("<html><p>Agility: "+ warrior.getAgility() +"/7" + "</p></html>");
	    speedbar.setToolTipText("<html><p>Speed: "+ (warrior.getSpeed() + weapon.getSpeed())+"/12" + "<br>Warrior: " + warrior.getSpeed()
		  + "<br>Weapon: " + weapon.getSpeed() + "</p></html>");
	}

	public JProgressBar getHealthpoints() {
		return healthpoints;
	}
	public void setHealthpoints(JProgressBar healthpoints) {
		this.healthpoints = healthpoints;
	}
	public JProgressBar getPowerbar() {
		return powerbar;
	}
	public void setPowerbar(JProgressBar powerbar) {
		this.powerbar = powerbar;
	}
	public JProgressBar getAgilitybar() {
		return agilitybar;
	}
	public void setAgilitybar(JProgressBar agilitybar) {
		this.agilitybar = agilitybar;
	}
	public JProgressBar getSpeedbar() {
		return speedbar;
	}
	public void setSpeedbar(JProgressBar speedbar) {
		this.speedbar = speedbar;
	}
	public JProgressBar getDefensebar() {
		return defensebar;
	}
	public void setDefensebar(JProgressBar defensebar) {
		this.defensebar = defensebar;
	}
}


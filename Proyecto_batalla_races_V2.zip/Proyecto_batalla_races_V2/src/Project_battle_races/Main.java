package Project_battle_races;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Main{
	private static Data datas;
	private static String username;
    public static void main(String[] args) {
    	datas = new Data();
    	username = datas.getUserfield().getText();
    	datas.getDatabaseuserfield().setText("root");
		datas.getPasswordfield().setText("toor");
    }
    
     Connection conn;
    public void createConnection() {
        String url = "jdbc:mysql://localhost/project?serverTimezone=UTC";
        String user = datas.getDatainput();
        String pass = datas.getPassinput();
        try {
//            Cargar driver
            Class.forName("com.mysql.cj.jdbc.Driver");
//            Crear coneccion
            conn = DriverManager.getConnection(url,user,pass);
        } catch (ClassNotFoundException e) {
            System.out.println("Driver not charged");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(datas, "The password or BBDD user is not correct");
        }

    }
	public Data getDatas() {
		return datas;
	}

	public String getUsername() {
		return username;
	}

	public Connection getConn() {
		return conn;
	}
	public void setConn(Connection conn) {
		this.conn = conn;
	}
    
}
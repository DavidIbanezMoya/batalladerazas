package Project_battle_races;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;



public class WarriorContainer extends Main{
	private ArrayList<Warrior> warriors = new ArrayList<Warrior>();
	
	public WarriorContainer() {
		
		try {
			createConnection();
			
			String query = "select * from race";
			Statement stmt = conn.createStatement();
			ResultSet rs1 = stmt.executeQuery(query);
			while(rs1.next()) {
				query = "select * from warriors where race_id = ?";
				PreparedStatement ps = conn.prepareStatement(query);
				ps.setInt(1, rs1.getInt(1));
				ResultSet rs2 = ps.executeQuery();
				while (rs2.next()) {
					
					if (rs1.getString(2).equals("Elf")) {
						
						warriors.add(new Elf(rs2.getInt(1), rs2.getString(2), rs2.getString(3), rs1.getString(2), 
										rs1.getInt(3), rs1.getInt(4), rs1.getInt(5), rs1.getInt(6), rs1.getInt(7)));
						
					}else if (rs1.getString(2).equals("Dwarf")) {
						
						warriors.add(new Dwarf(rs2.getInt(1), rs2.getString(2), rs2.getString(3), rs1.getString(2), 
										rs1.getInt(3), rs1.getInt(4), rs1.getInt(5), rs1.getInt(6), rs1.getInt(7)));
						
					}else if (rs1.getString(2).equals("Human")) {
						
						warriors.add(new Human(rs2.getInt(1), rs2.getString(2), rs2.getString(3), rs1.getString(2), 
										rs1.getInt(3), rs1.getInt(4), rs1.getInt(5), rs1.getInt(6), rs1.getInt(7)));
					}
				}
			}
			
		} catch (SQLException e) {
		System.out.println("Error de SQL.");
		
		}
	}
	public ArrayList<Warrior> getWarriors() {
        return warriors;
    }
}

class Warrior{
	private int id ;
	private String name;
	private String image;
	private String race;
	private int hp;
	private int strength;
	private int speed;
	private int agility;
	private int defense;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getRace() {
		return race;
	}
	public void setRace(String race) {
		this.race = race;
	}
	public int getHp() {
		return hp;
	}
	public void setHp(int hp) {
		this.hp = hp;
	}
	public int getStrength() {
		return strength;
	}
	public void setStrength(int strength) {
		this.strength = strength;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public int getAgility() {
		return agility;
	}
	public void setAgility(int agility) {
		this.agility = agility;
	}
	public int getDefense() {
		return defense;
	}
	public void setDefense(int defense) {
		this.defense = defense;
	}
	
}

class Elf extends Warrior{

	public Elf(int id, String name, String image, String race, int hp, int strength, int speed, int agility, int defense) {
		super();
		setId(id);
		setName(name);
		setImage(image);
		setRace(race);
		setHp(hp);
		setStrength(strength);
		setSpeed(speed);
		setAgility(agility);
		setDefense(defense);
	}
	
}

class Dwarf extends Warrior{

	public Dwarf(int id, String name, String image, String race, int hp, int strength, int speed, int agility, int defense) {
		super();
		setId(id);
		setName(name);
		setImage(image);
		setRace(race);
		setHp(hp);
		setStrength(strength);
		setSpeed(speed);
		setAgility(agility);
		setDefense(defense);
	}
	
}

class Human extends Warrior{

	public Human(int id, String name, String image, String race, int hp, int strength, int speed, int agility, int defense) {
		super();
		setId(id);
		setName(name);
		setImage(image);
		setRace(race);
		setHp(hp);
		setStrength(strength);
		setSpeed(speed);
		setAgility(agility);
		setDefense(defense);
	}
	
}

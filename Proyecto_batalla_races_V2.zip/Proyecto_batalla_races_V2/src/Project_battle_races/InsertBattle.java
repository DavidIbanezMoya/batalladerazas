package Project_battle_races;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertBattle extends Main {
    private int player_id, warr_id, warr_weapon_id, opp_id, opp_weapon_id;
    private String player;
    public InsertBattle(Warrior warrior, Weapon warrior_weapon, Warrior opponent, Weapon opponent_weapon, int inj_caus, int inj_suff, int battPoints) {
        player_id = 0;
        player = getDatas().getUserfield().getText();
        warr_id = warrior.getId();
        warr_weapon_id = warrior_weapon.getId();
        opp_id =  opponent.getId();
        opp_weapon_id =  opponent_weapon.getId();
              
        try {
            createConnection();
            String query = "Select player_id from players where player_name ='"+player+"'";
            
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while(rs.next()) {
                player_id = rs.getInt(1);
            }
            query = "Insert into battle(player_id,warrior_id,warrior_weapon_id,opponent_id,opponent_weapon_id,injuries_caused,injuries_suffered,battle_points) values("+player_id+","+warr_id+","+warr_weapon_id+","+opp_id+","+opp_weapon_id+","+inj_caus+","+inj_suff+","+battPoints+")";
            stmt.executeUpdate(query);
        }catch (SQLException es) {
            System.out.println(es);
            
            }

    }
    public String getPlayer() {
        return player;
    }
    public void setPlayer(String player) {
        this.player = player;
    }
    
}

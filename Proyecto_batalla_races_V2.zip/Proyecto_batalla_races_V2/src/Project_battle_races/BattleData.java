package Project_battle_races;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class BattleData extends Main{
private ArrayList<Battle> battData = new ArrayList<Battle>();
	
	public BattleData() {
		
		try {
			createConnection();
			String query = "select * from battle order by battle_id asc limit 20";
			Statement stmt = conn.createStatement();
			ResultSet rs1 = stmt.executeQuery(query);
			while (rs1.next()) {
				battData.add(new Battle(rs1.getInt(1), rs1.getString(2),rs1.getInt(3), rs1.getInt(4), rs1.getInt(5),rs1.getInt(6),rs1.getInt(7),rs1.getInt(8),rs1.getInt(9)));
				}
			} catch (SQLException e) {
			System.out.println("Error de SQL.");
			
		}
	}

	public ArrayList<Battle> getBattData() {
		return battData;
	}

	public void setBattData(ArrayList<Battle> battData) {
		this.battData = battData;
	}
	
}

class Battle {
	private int id;
	private String player_id;
	private int warr_id;
	private int warr_weapon_id;
	private int opp_id;
	private int opp_weapon_id;
	private int injuries_caused;
	private int injuries_suffered;
	private int battle_points;
	
	public Battle(int id, String player_id, int warr_id, int warr_weapon_id, int opp_id, int opp_weapon_id,
			int injuries_caused, int injuries_suffered, int battle_points) {
		super();
		this.id = id;
		this.player_id = player_id;
		this.warr_id = warr_id;
		this.warr_weapon_id = warr_weapon_id;
		this.opp_id = opp_id;
		this.opp_weapon_id = opp_weapon_id;
		this.injuries_caused = injuries_caused;
		this.injuries_suffered = injuries_suffered;
		this.battle_points = battle_points;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPlayer_id() {
		return player_id;
	}

	public void setPlayer_id(String player_id) {
		this.player_id = player_id;
	}

	public int getWarr_id() {
		return warr_id;
	}

	public void setWarr_id(int warr_id) {
		this.warr_id = warr_id;
	}

	public int getWarr_weapon_id() {
		return warr_weapon_id;
	}

	public void setWarr_weapon_id(int warr_weapon_id) {
		this.warr_weapon_id = warr_weapon_id;
	}

	public int getOpp_id() {
		return opp_id;
	}

	public void setOpp_id(int opp_id) {
		this.opp_id = opp_id;
	}

	public int getOpp_weapon_id() {
		return opp_weapon_id;
	}

	public void setOpp_weapon_id(int opp_weapon_id) {
		this.opp_weapon_id = opp_weapon_id;
	}

	public int getInjuries_caused() {
		return injuries_caused;
	}

	public void setInjuries_caused(int injuries_caused) {
		this.injuries_caused = injuries_caused;
	}

	public int getInjuries_suffered() {
		return injuries_suffered;
	}

	public void setInjuries_suffered(int injuries_suffered) {
		this.injuries_suffered = injuries_suffered;
	}

	public int getBattle_points() {
		return battle_points;
	}

	public void setBattle_points(int battle_points) {
		this.battle_points = battle_points;
	}
	
	

}

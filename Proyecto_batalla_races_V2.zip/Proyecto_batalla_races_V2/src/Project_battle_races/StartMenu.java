package Project_battle_races;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class StartMenu extends JFrame implements ActionListener{
	private JPanel top_buttons,bottom_buttons,center_general, weapon_panel, warriors_panel;
	private JButton choosechar, chooseweap, history, fight, clconsole, button;
    private Character user,bot;
    private JTextArea txtConsole;    
    private Warrior warrior;
    private Weapon warrior_weapon;
    private Warrior opponent;
    private Weapon opponent_weapon;
    private ArrayList<Weapon> weapon_available = new ArrayList<Weapon>();
    private ArrayList<Weapon> weapons = new WeaponContainer().getWeapons();
    private ArrayList<Warrior> warriors = new WarriorContainer().getWarriors();
    private int rows, cont, count_funny=0, rand, length, turn = 1, puntuation = 0;
    private JPanelBackground center_battle, back;
    private JLabel phrase;
	private boolean userAtac = false;
	private boolean fight_on = false;
	
	
	public StartMenu() {

		setResizable(false);
		setTitle("1% DE POSIBILIDAD 99% DE FE");
		setBounds(125,0,1300,820);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		user = new Character();
		user.setOpaque(false);
		
		bot = new Character();
		bot.setOpaque(false);
	
		choosechar = new JButton("Choose character");
		choosechar.addActionListener(this);
		
		chooseweap = new JButton("Choose weapon");
		chooseweap.addActionListener(this);
		
		history = new JButton("History");
		history.addActionListener(this);
		
		top_buttons = new JPanel();
		top_buttons.setOpaque(false);
		top_buttons.setPreferredSize(new Dimension(800,50));
		top_buttons.add(choosechar);
		top_buttons.add(chooseweap);
		top_buttons.add(history);
		
		center_general = new JPanel();
		center_general.setOpaque(false);
		center_general.setLayout(new BoxLayout(center_general, BoxLayout.X_AXIS));
		center_general.add(user);
		center_general.add(Box.createHorizontalStrut(125));
		center_general.add(bot);
		
		fight = new JButton("Fight");
	    fight.addActionListener(this);
	    
		clconsole = new JButton("Clear console");
		clconsole.addActionListener(this);
		
		bottom_buttons = new JPanel();
		bottom_buttons.setOpaque(false);
		bottom_buttons.add(fight);
		bottom_buttons.add(clconsole);
				
		center_battle = new JPanelBackground();
		center_battle.setBackgroundI("images/dbz.jpg");
		center_battle.setLayout(new BoxLayout(center_battle, BoxLayout.Y_AXIS));
		center_battle.add(top_buttons);
		center_battle.add(center_general);
		center_battle.add(bottom_buttons);
		
		//Terminal
		txtConsole = new JTextArea(7,0);
		txtConsole.setEditable(false);
        JScrollPane jsp = new JScrollPane(txtConsole);
        jsp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        jsp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        PrintStream out = new PrintStream( new ConsoleJFrame( txtConsole ));
        System.setOut( out );       
        
        add(center_battle, BorderLayout.CENTER);
		add(jsp,BorderLayout.SOUTH);
        
		setVisible(true);	
	}
	

	
	public void getRandomWarrior() {
		
		
		
		length = warriors.size();
		int rand = (int)(Math.random()*length + length*3);
		cont = length-1;
		disableAllButtons();
            Timer tt = new Timer();
            
            // Creamos un objeto de la clase TimerTask para definir la tarea en el metodo run
            TimerTask animation = new TimerTask() {
            	
                public void run() {
                	
                	if (cont == rand) {
                		tt.cancel();
                		tt.purge();
                		opponent = warriors.get(cont%length);
                		bot.characterImage(opponent.getImage());
                		bot.getHealthpoints().setMaximum(opponent.getHp());
                		bot.getHealthpoints().setValue(opponent.getHp());
                		bot.getPowerbar().setValue(opponent.getStrength());
                		bot.getDefensebar().setValue(opponent.getDefense());
                		bot.getAgilitybar().setValue(opponent.getAgility());
                		bot.getSpeedbar().setValue(opponent.getSpeed());
                        
                		try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                		
                		getRandomWeapon();
                		return;

                	}
                	
                	cont++;                    
                    bot.characterImage(warriors.get(cont%length).getImage());
                    setVisible(true);
                    
                }
            };
            tt.schedule(animation, 0, 60);                       
        
	}
	
	public void weaponAvailable(Warrior warrior) {
		try {
			weapon_available.clear();
			for (Weapon weap: weapons) {
				if (weap.getRace().contains(warrior.getRace())) {
					weapon_available.add(weap);
				}
			}
		}catch(Exception es) {
			
		}
	}	
	
	public void getRandomWeapon() {
		disableAllButtons();
        weaponAvailable(opponent);
        length = weapon_available.size();
        rand = (int)(Math.random()*length + length*5);
        cont = length-1;
       
        Timer tt = new Timer();
        
        // Creamos un objeto de la clase TimerTask para definir la tarea en el metodo run
        TimerTask animation= new TimerTask() {
        	
            public void run() {
            	
            	if (cont == rand) {
            		tt.cancel();
            		tt.purge();
            		opponent_weapon = weapon_available.get(cont%length);
            		bot.weaponImage(opponent_weapon.getImage());
            		bot.getSpeedbar().setValue(opponent.getSpeed() + opponent_weapon.getSpeed());
            		bot.getPowerbar().setValue(opponent.getStrength() + opponent_weapon.getStrength());
            		bot.setDates(opponent, opponent_weapon);
            		enableAllButtons();
         
            		return;

            	}
                cont++;
            	
                bot.weaponImage(weapon_available.get(cont%length).getImage());
                setVisible(true);
                
            }
        };
        tt.schedule(animation, 0, 60); 
	}	    

	public void showMessage(String message) {
		JOptionPane.showMessageDialog(this, message,"Error",JOptionPane.WARNING_MESSAGE);
	}
		
	
	class WarriorSelectWindow extends JFrame{
		
		public WarriorSelectWindow() {
			
			disableAllButtons();

			rows = (int)warriors.size()/4;
			if (warriors.size()%4 != 0) {
				rows++;
			}
			
			setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
			setSize(1310,200*rows + 20*(rows-1) + 180);
			setLocationRelativeTo(null);
			setResizable(false);
			
			warriors_panel = new JPanel();
			warriors_panel.setOpaque(false);			
			warriors_panel.setPreferredSize(new Dimension(1270, 200*rows + 20*(rows-1)));
			
			phrase = new JLabel("Choose your warrior");
			phrase.setForeground( Color.WHITE);
			phrase.setFont(new Font("Times New Roman", Font.BOLD, 30));
			
			back = new JPanelBackground();
			back.setBackgroundI("images/back.jpg");
			back.add(phrase);
			back.add(Box.createVerticalStrut(70));

			for (Warrior unit: warriors) {
				Toolkit tools = Toolkit.getDefaultToolkit();
		        Image icon = tools.getImage(unit.getImage());
		        Image correctedImage = icon.getScaledInstance(300, 200, Image.SCALE_SMOOTH);
		        ImageIcon imageIcon = new ImageIcon(correctedImage);
		        button = new JButton(imageIcon);
		        button.setToolTipText("<html><p>" + unit.getName() + "<br>Race: " + unit.getRace() + "<br>HP: " + unit.getHp() 
		        					  + "<br>Power: " + unit.getStrength() + "<br>Speed: " + unit.getSpeed() + "<br>Agility: " 
		        					  + unit.getAgility() + "<br>Defense: " + unit.getDefense() + "</p></html>");
		        
		        warriors_panel.add(button);
			    button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						warrior = unit;
						user.characterImage(warrior.getImage());
						user.getHealthpoints().setMaximum(warrior.getHp());
						user.getHealthpoints().setValue(warrior.getHp());
						user.getPowerbar().setValue(warrior.getStrength());
						user.getDefensebar().setValue(warrior.getDefense());
						user.getAgilitybar().setValue(warrior.getAgility());
						user.getSpeedbar().setValue(warrior.getSpeed());
						dispose();
						new WeaponSelectWindow();
						}
					});
			    	
			}
			warriors_panel.setLayout(new GridLayout(0,4,20,20));
			back.add(warriors_panel);
			add(back);
			setVisible(true);
		}
	}
		
	class WeaponSelectWindow extends JFrame{		
		
		public WeaponSelectWindow(){
			
			disableAllButtons();
			if (warrior != null) {
				
				weaponAvailable(warrior);
				
				rows = (int)weapon_available.size()/4;
				if (weapon_available.size()%4!=0) {
					rows++;
				}
				
				setResizable(false);
				setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
				setSize(910,200*rows + 20*(rows-1) + 180);
				setLocation(310, 100);
				
				weapon_panel = new JPanel();
				weapon_panel.setOpaque(false);
				weapon_panel.setPreferredSize(new Dimension(870, 200*rows + 20*(rows-1)));

				phrase = new JLabel("Choose your weapon");
				phrase.setForeground( Color.WHITE);
				phrase.setFont(new Font("Times New Roman", Font.BOLD, 30));
				
				back = new JPanelBackground();
				back.setBackgroundI("images/back2.jpg");
				back.add(phrase);
				back.add(Box.createVerticalStrut(70));				

				for (Weapon unit: weapon_available) {
					Toolkit tools = Toolkit.getDefaultToolkit();
			        Image icon = tools.getImage(unit.getImage());
			        Image correctedImage = icon.getScaledInstance(200, 200, Image.SCALE_SMOOTH);
			        ImageIcon imageIcon = new ImageIcon(correctedImage);
			        button = new JButton(imageIcon);
			        button.setToolTipText("<html><p>" + unit.getName() +  "<br>Power: " + unit.getStrength()
			        					  + "<br>Speed: " + unit.getSpeed() + "</p></html>");
			        
			        weapon_panel.add(button);
				    button.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							warrior_weapon = unit;
							user.weaponImage(warrior_weapon.getImage());
							user.getSpeedbar().setValue(warrior.getSpeed()+warrior_weapon.getSpeed());
							user.getPowerbar().setValue(warrior.getStrength()+warrior_weapon.getStrength());
							user.setDates(warrior, warrior_weapon);
							dispose();
							getRandomWarrior();
						}
						
					});
				}
				weapon_panel.setLayout(new GridLayout(0,4,20,20));
		
				back.add(weapon_panel);
				add(back, BorderLayout.CENTER);
				setVisible(true);
				
			}else {
				if (count_funny==0) {
					showMessage("If you do it again I will install a virus on your PC");
					enableAllButtons();
					count_funny++;
				}else if(count_funny==1) {
					showMessage("Didn't you hear me? I will do it");
					enableAllButtons();
					count_funny++;
				}else if(count_funny==2) {
					showMessage("STOOOOP!!!!!!!");
					enableAllButtons();
					count_funny++;
				}else if(count_funny==3) {
					center_battle.setBackgroundI("images/infected_back.jpg");
					choosechar.setBackground(Color.GREEN);
					chooseweap.setBackground(Color.GREEN);
					history.setBackground(Color.GREEN);
					fight.setBackground(Color.magenta);
					clconsole.setBackground(Color.magenta);
					showMessage("Are you satisfied???");
					enableAllButtons();
					count_funny++;
				}else {
					showMessage("You already have it. Enjoy");
					enableAllButtons();
				}
			}
			}
		}
	
	public void attack(String attacker) {
		boolean attack = true;
		int damage = 0;
		int percentFail;
		int percentDodge;
		int percentSecondAttack;
		boolean secondAttack = false;
	
		while (attack) {
			
			percentFail = (int)(Math.random()*100)+1;
			percentDodge = (int)(Math.random()*50)+1;
			percentSecondAttack = (int)(Math.random()*100)+1;
			if (attacker.equals("user")) {
				if ((warrior.getAgility()*10) >= percentFail) {
					if(opponent.getAgility() >= percentDodge) {
						System.out.println(opponent.getName()+" dodged the attack");
					}else {
						damage = (warrior.getStrength() + warrior_weapon.getStrength()) - opponent.getDefense();
						bot.getHealthpoints().setValue(bot.getHealthpoints().getValue()-damage);
						System.out.println(warrior.getName()+" dealt "+damage+" damage");
					}
				}else {
					System.out.println(warrior.getName()+" missed the attack");
				}
				attack = false;
				if (!secondAttack && warrior.getSpeed() + warrior_weapon.getSpeed() > opponent.getSpeed() + opponent_weapon.getSpeed()) {
					secondAttack = true;
					if((warrior.getSpeed() + warrior_weapon.getSpeed() - opponent.getSpeed() + opponent_weapon.getSpeed())*10 > percentSecondAttack) {
						attack = true;
					}
				}      
			}else {
				if ((opponent.getAgility()*10) >= percentFail) {
					if(warrior.getAgility() >= percentDodge) {
						System.out.println(warrior.getName()+" dodged the attack");
					}else {
						damage = (opponent.getStrength() + opponent_weapon.getStrength()) - warrior.getDefense();
						user.getHealthpoints().setValue(user.getHealthpoints().getValue()-damage);
						System.out.println(opponent.getName()+" dealt "+damage+" damage");
					}
				}else {
					System.out.println(opponent.getName()+" missed the attack");
				}
				attack = false;
				if (!secondAttack && opponent.getSpeed() + opponent_weapon.getSpeed() > warrior.getSpeed() + warrior_weapon.getSpeed()) {
					secondAttack = true;
					if((opponent.getSpeed() + opponent_weapon.getSpeed() - warrior.getSpeed() + warrior_weapon.getSpeed())*10 > percentSecondAttack) {
						attack = true;
					}
				}      
				
			}
		}
	}
	
	
	public void disableTopButtons(){
		choosechar.setEnabled(false);
		chooseweap.setEnabled(false);
		history.setEnabled(false);
	}
	
	public void disableAllButtons(){
		choosechar.setEnabled(false);
		chooseweap.setEnabled(false);
		history.setEnabled(false);
		fight.setEnabled(false);
		clconsole.setEnabled(false);
	}
	
	public void enableAllButtons(){
		choosechar.setEnabled(true);
		chooseweap.setEnabled(true);
		history.setEnabled(true);
		fight.setEnabled(true);
		clconsole.setEnabled(true);
	}
	
	
	public void actionPerformed(ActionEvent e) {
		
		
			if (e.getActionCommand().equals("History")) {
				new History();
			}
			
			
			else if (e.getActionCommand().equals("Choose character") ) {
	            
				if (puntuation>0) {
					new InsertRanking(warrior, warrior_weapon, puntuation);
					puntuation = 0;
				}
				new WarriorSelectWindow();
	
	        }    
	        else if (e.getActionCommand().equals("Choose weapon")) {
	            
	        	if (puntuation>0) {
					new InsertRanking(warrior, warrior_weapon, puntuation);
					puntuation = 0;
				}
	             new WeaponSelectWindow();

	        }else if (e.getActionCommand().equals("Clear console")) {
				  
				txtConsole.setText("");
				
	        }else if (e.getActionCommand().equals("Fight")) {
	        	
	        	if (warrior == null) {
	        		showMessage("You can not start a fight without a warrior");
	        	}else {
	        	
	        		disableTopButtons();
					if (user.getHealthpoints().getValue() <= warrior.getHp()*0.50 ) {
						user.getHealthpoints().setForeground(Color.yellow);
					}
					if (user.getHealthpoints().getValue() <= warrior.getHp()*0.20 ) {
						user.getHealthpoints().setForeground(Color.red);
					}
					if (bot.getHealthpoints().getValue() <= opponent.getHp()*0.50 ) {
						bot.getHealthpoints().setForeground(Color.yellow);
					}
					if (bot.getHealthpoints().getValue() <= opponent.getHp()*0.20 ) {
						bot.getHealthpoints().setForeground(Color.red);
					}
					
					if(user.getHealthpoints().getMaximum() == user.getHealthpoints().getValue() && bot.getHealthpoints().getMaximum() == bot.getHealthpoints().getValue() && turn == 1 ) {
						if(warrior.getSpeed() + warrior_weapon.getSpeed() < opponent.getSpeed() + opponent_weapon.getSpeed()) {
							System.out.println("Bot Starts");
						}else if(warrior.getSpeed() + warrior_weapon.getSpeed() == opponent.getSpeed() + opponent_weapon.getSpeed()){
							if(warrior.getAgility() < opponent.getAgility()) {
								System.out.println("Bot Starts");
							}else if (warrior.getAgility() == opponent.getAgility()) {
								System.out.println("User Starts");
								userAtac = true;
							}else if (warrior.getAgility() == opponent.getAgility()) {
								int randomAtac = (int)(Math.random()*1);
								System.out.println(randomAtac);
								if(randomAtac == 1) {
									System.out.println("Bot Starts");
								}else {
									System.out.println("User Starts");
									userAtac = true;
								}
							}	
						}
						else {
							System.out.println("User Starts");
							userAtac = true;
						}
					}
					
					//User atack
					
					System.out.println("\nTurn: "+turn);
					if (userAtac) {
						attack("user");
						userAtac = false;
							
					//Bot attack
					}else {
						attack("bot");
						userAtac = true;
					}
							
							
						
					if (user.getHealthpoints().getValue() != 0 && bot.getHealthpoints().getValue() != 0) {
						turn++;
						fight_on = true;
//						if (user.getHealthpoints().getValue() <= warrior.getHp()*0.30  && bot.getHealthpoints().getValue() <= opponent.getHp()*0.30) {
//						}
							
					}else {
						new InsertBattle(warrior, warrior_weapon, opponent, opponent_weapon, opponent.getHp()-bot.getHealthpoints().getValue(),  warrior.getHp()-user.getHealthpoints().getValue(), user.getHealthpoints().getValue());
						fight_on = false;
						int playAgain = 0;
						
						if(user.getHealthpoints().getValue() <= 0) {
							
							playAgain = JOptionPane.showConfirmDialog(this, "Bot won!!! \nPlay Again?","Confirmation",JOptionPane.YES_NO_OPTION);
							if(JOptionPane.YES_OPTION == playAgain) {
								new InsertRanking(warrior, warrior_weapon, puntuation);
								puntuation = 0;
								new WarriorSelectWindow();
								turn = 1;
								user.getHealthpoints().setForeground(Color.green);
								bot.getHealthpoints().setForeground(Color.green);
								user.getHealthpoints().setValue(warrior.getHp());
								bot.getHealthpoints().setValue(opponent.getHp());
								
							}else {
								new InsertRanking(warrior, warrior_weapon, puntuation);
								super.dispose();
							}
						}else if (bot.getHealthpoints().getValue() <= 0) {
							puntuation += user.getHealthpoints().getValue();
					        playAgain = JOptionPane.showConfirmDialog(this, "User won!!!  \nPlay Again?","Confirmation",JOptionPane.YES_NO_OPTION);
					        if(JOptionPane.YES_OPTION == playAgain) {
					        	getRandomWarrior();
								turn = 1;
								user.getHealthpoints().setForeground(Color.green);
								bot.getHealthpoints().setForeground(Color.green);
					        	user.getHealthpoints().setValue(warrior.getHp());
								bot.getHealthpoints().setValue(opponent.getHp());					
							}else {
								new InsertRanking(warrior, warrior_weapon, puntuation);
								puntuation = 0;
								super.dispose();
							}
						}
						txtConsole.setText("");
					}
	        	}
			
				
			}else {
				showMessage("You can't do it while you are in a fight");
				enableAllButtons();
	        }
		
		
		
		}


}
class JPanelBackground extends JPanel {
	 
	// Atributo que guardara la imagen de Background que le pasemos.
	private Image background;
 
	// Metodo que es llamado automaticamente por la maquina virtual Java cada vez que repinta
	public void paintComponent(Graphics g) {
 
		/* Obtenemos el tamaño del panel para hacer que se ajuste a este
		cada vez que redimensionemos la ventana y se lo pasamos al drawImage */
		int width = this.getSize().width;
		int height = this.getSize().height;
 
		// Mandamos que pinte la imagen en el panel
		if (this.background != null) {
			g.drawImage(this.background, 0, 0, width, height, null);
		}
 
		super.paintComponent(g);
	}
 
	// Metodo donde le pasaremos la dirección de la imagen a cargar.
	public void setBackgroundI(String imagePath) {
		
		// Construimos la imagen y se la asignamos al atributo background.
		this.setOpaque(false);
		this.background = new ImageIcon(imagePath).getImage();
		repaint();
	}
 
}

class ConsoleJFrame extends OutputStream {
    private JTextArea textArea;

    public ConsoleJFrame( JTextArea text ) {
        textArea = text;
    }

    public void write(int b) throws IOException {
        textArea.append( String.valueOf((char)b) );
    }
  
}
package Project_battle_races;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class RankingData extends Main{
	private ArrayList<Rank> rankData = new ArrayList<Rank>();
	
	public RankingData() {
		
		try {
			createConnection();
			String query = "select * from ranking order by puntuation desc";
			Statement stmt = conn.createStatement();
			ResultSet rs1 = stmt.executeQuery(query);
			while (rs1.next()) {
				rankData.add(new Rank(rs1.getInt(1), rs1.getString(2),rs1.getInt(3), rs1.getString(4), rs1.getString(5),rs1.getInt(6)));
				}
			} catch (SQLException e) {
			System.out.println("Error de SQL.");
			
		}
		
		
	}

	public ArrayList<Rank> getRankData() {
		return rankData;
	}

	public void setRankData(ArrayList<Rank> rankData) {
		this.rankData = rankData;
	}
}

class Rank {
	private int id;
	private String player;
	private int warrior_id;
	private String warrior_name;
	private String weapon_name;
	private int puntuation;
	
	public Rank(int id, String player, int warrior_id, String warrior_name, String weapon_name, int puntuation) {
		super();
		this.id = id;
		this.player = player;
		this.warrior_id = warrior_id;
		this.warrior_name = warrior_name;
		this.weapon_name = weapon_name;
		this.puntuation = puntuation;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPlayer() {
		return player;
	}

	public void setPlayer(String player) {
		this.player = player;
	}

	public int getWarrior_id() {
		return warrior_id;
	}

	public void setWarrior_id(int warrior_id) {
		this.warrior_id = warrior_id;
	}

	public String getWarrior_name() {
		return warrior_name;
	}

	public void setWarrior_name(String warrior_name) {
		this.warrior_name = warrior_name;
	}

	public String getWeapon_name() {
		return weapon_name;
	}

	public void setWeapon_name(String weapon_name) {
		this.weapon_name = weapon_name;
	}

	public int getPuntuation() {
		return puntuation;
	}

	public void setPuntuation(int puntuation) {
		this.puntuation = puntuation;
	}
	
}


package Project_battle_races;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.xdevapi.Result;


public class InsertRanking extends Main {
    private int player_id,warr_id;
    private String player, warr_name, warr_weapon_name;
    public InsertRanking(Warrior warrior, Weapon weapon, int  points) {
        player_id = 0;
        player = getDatas().getUserfield().getText();
        warr_id = warrior.getId();
        warr_name = warrior.getName();
        warr_weapon_name = weapon.getName();
        
        
        try {
            createConnection();
            String query = "Select player_id from players where player_name ='"+player+"'";
            
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while(rs.next()) {
                player_id = rs.getInt(1);
            }
            query = "Insert into ranking values("+player_id+",'"+player+"',"+warr_id+",'"+warr_name+"','"+warr_weapon_name+"',"+points+")";
            stmt.executeUpdate(query);
        }catch (SQLException es) {
            System.out.println(es);
            
            }
    }
}

package Project_battle_races;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;

public class History extends JFrame{
	private JScrollPane jscprk,jscpmh;
	private JTable ranking,mhistory;
	private RankingData rd;
	private JTabbedPane jtb;
	private BattleData bd;

	public History() {
		jtb = new JTabbedPane();
				
		rd = new RankingData();
		
		String []nameCol = {"Player","WarriorID","Warrior","Weapon","Puntuation"};
		String[][] data= new String[rd.getRankData().size()][5];
		for (int i = 0; i <rd.getRankData().size(); i++) {
			data[i][0] = rd.getRankData().get(i).getPlayer();
			data[i][1] = String.valueOf(rd.getRankData().get(i).getWarrior_id());
			data[i][2] = rd.getRankData().get(i).getWarrior_name();
			data[i][3] = rd.getRankData().get(i).getWeapon_name();
			data[i][4] = String.valueOf(rd.getRankData().get(i).getPuntuation());
		}
		
		ranking = new JTable(data,nameCol);
		ranking.setRowHeight(24);
		ranking.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		ranking.setShowVerticalLines(false);
		
		jscprk = new JScrollPane(ranking);
		jtb.addTab("Ranking", jscprk);
		
		bd = new BattleData();
		
		String []nameCol2 = {"BattleID","PlayerID","WarriorID","Warrior_WeaponID","OpponentID","Opponent_WeaponID","Injuries Caused","Injuries Suffered","Battle Points"};
		String[][] data2= new String[bd.getBattData().size()][9];
		for (int i = 0; i <bd.getBattData().size(); i++) {
			data2[i][0] = String.valueOf(bd.getBattData().get(i).getId());
			data2[i][1] = String.valueOf(bd.getBattData().get(i).getPlayer_id());
			data2[i][2] = String.valueOf(bd.getBattData().get(i).getWarr_id());
			data2[i][3] = String.valueOf(bd.getBattData().get(i).getWarr_weapon_id());
			data2[i][4] = String.valueOf(bd.getBattData().get(i).getOpp_id());
			data2[i][5] = String.valueOf(bd.getBattData().get(i).getOpp_weapon_id());
			data2[i][6] = String.valueOf(bd.getBattData().get(i).getInjuries_caused());
			data2[i][7] = String.valueOf(bd.getBattData().get(i).getInjuries_suffered());
			data2[i][8] = String.valueOf(bd.getBattData().get(i).getBattle_points());
		}
		mhistory = new JTable(data2,nameCol2);
		
		mhistory.setRowHeight(24);
		mhistory.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		mhistory.setShowVerticalLines(false);
		
		jscpmh = new JScrollPane(mhistory);
		jtb.addTab("Match History", jscpmh);
		
		this.add(jtb);
		this.setBounds(500,250,400,400);
		this.setTitle("History");
		this.setVisible(true);
	}

	
}

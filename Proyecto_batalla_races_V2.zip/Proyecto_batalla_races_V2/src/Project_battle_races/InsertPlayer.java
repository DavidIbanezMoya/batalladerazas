package Project_battle_races;

import java.sql.SQLException;
import java.sql.Statement;

public class InsertPlayer extends Main {
	public InsertPlayer() {
		
		try {
			String player = getDatas().getUserfield().getText();
			createConnection();
			
			String query = "Insert into players(player_name) values('"+player+"')";
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(query);
			
		} catch (SQLException e) {
		
		}
	}
}
